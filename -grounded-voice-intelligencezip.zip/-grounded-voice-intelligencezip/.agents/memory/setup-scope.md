---
name: Imported project setup scope
description: Keep local demos usable independently of live voice-provider integrations.
---

Use the credential-free local demo as the default for this imported project's Replit setup. Preserve the existing stack and structure.

**Why:** The user requested getting the import running, not enabling external voice services. Provider-dependent behavior must not prevent using the local qualification demo.

**How to apply:** Treat live voice-provider setup as separate work requiring verified configuration; do not imply that passing local tests verifies carrier calls or provider speech.