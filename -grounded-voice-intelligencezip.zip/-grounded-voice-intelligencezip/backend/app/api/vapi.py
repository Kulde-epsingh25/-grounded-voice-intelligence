"""
Vapi Integration — FastAPI Webhook Router.

Handles incoming Vapi tool-calls and events:
- function: search_knowledge -> Q2 hybrid retrieval
- function: evaluate_qualification -> deterministic rules
- function: create_lead -> lead service
- function: escalate_to_human -> escalation logging
"""

from __future__ import annotations

import json
from typing import Any, Optional

from fastapi import APIRouter, Header, HTTPException, Request

from app.agents.tools import (
    create_lead_tool,
    escalate_to_human_tool,
    evaluate_qualification_tool,
    search_knowledge,
)
from app.core.config import get_config
from app.core.logging import get_logger
from app.integrations.vapi.assistant import build_assistant_config
from app.services.call_events import get_call_event_service

logger = get_logger(__name__)

router = APIRouter()


@router.post("/webhook")
async def handle_vapi_webhook(
    request: Request,
    x_vapi_secret: Optional[str] = Header(None, alias="X-Vapi-Secret"),
) -> dict[str, Any]:
    """Handle Vapi tool calls and call status events."""
    config = get_config()

    # Webhook secret verification (if configured in environment)
    if config.is_production and not config.webhook.vapi_secret:
        raise HTTPException(status_code=503, detail="Vapi webhooks are disabled until a webhook secret is configured.")
    if config.webhook.vapi_secret and x_vapi_secret != config.webhook.vapi_secret:
        logger.warning("Unauthorized Vapi webhook call attempt")
        raise HTTPException(status_code=401, detail="Invalid webhook secret")

    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Malformed JSON payload")

    message_data = body.get("message", body)
    msg_type = message_data.get("type", "")
    call_info = message_data.get("call", {})
    call_id = call_info.get("id", "call_unknown")

    # 1. Handle Tool Calls
    if msg_type in ("tool-calls", "tool_calls") or "toolCalls" in message_data:
        tool_calls = message_data.get("toolCalls", [])
        results = []

        for call in tool_calls:
            call_id_val = call.get("id", "")
            func = call.get("function", {})
            func_name = func.get("name", "")
            raw_args = func.get("arguments", {})

            if isinstance(raw_args, str):
                try:
                    args = json.loads(raw_args)
                except Exception:
                    args = {}
            else:
                args = raw_args

            logger.info(
                f"Vapi tool executed: {func_name}",
                extra={"extra_data": {"call_id": call_id, "tool": func_name}},
            )

            # Dispatch tool
            if func_name == "search_knowledge":
                query = args.get("query", "")
                tool_res = search_knowledge(query)
            elif func_name == "evaluate_qualification":
                tool_res = evaluate_qualification_tool(args)
            elif func_name == "create_lead":
                tool_res = create_lead_tool(
                    call_id=call_id,
                    fields=args.get("fields", {}),
                    contact_permission=args.get("contact_permission", True),
                    notes=args.get("notes", ""),
                )
            elif func_name == "escalate_to_human":
                reason = args.get("reason", "Caller requested human assistance")
                tool_res = escalate_to_human_tool(call_id=call_id, reason=reason)
            else:
                tool_res = {"error": f"Unknown function {func_name}"}

            results.append({"toolCallId": call_id_val, "result": tool_res})

        return {"results": results}

    # 2. Handle Status Update Events
    if msg_type == "status-update":
        status = message_data.get("status")
        get_call_event_service().log_event(
            call_id=call_id,
            event_type=f"call_{status}",
            payload={"status": status},
        )
        return {"status": "received"}

    # 3. Handle End of Call
    if msg_type == "end-of-call-report":
        get_call_event_service().log_event(
            call_id=call_id,
            event_type="call_ended",
            payload=message_data,
        )
        return {"status": "recorded"}

    return {"status": "ok"}


@router.get("/config")
async def get_public_vapi_config() -> dict[str, Any]:
    """Return sanitized assistant configuration for UI without private keys."""
    config = get_config()
    asst_config = build_assistant_config()

    return {
        # The browser Web SDK uses the public key and existing assistant ID.
        # The private API key is only needed for server-side Vapi REST operations.
        "configured": bool(config.vapi.public_key and config.vapi.assistant_id),
        "management_api_configured": bool(config.vapi.api_key),
        "webhook_ready": bool(config.vapi.public_base_url and config.webhook.vapi_secret),
        "public_key": config.vapi.public_key,
        "assistant_id": config.vapi.assistant_id,
        "public_base_url": config.vapi.public_base_url,
        "assistant": asst_config.model_dump(mode="json"),
    }
